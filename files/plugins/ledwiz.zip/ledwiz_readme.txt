=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Mala LEDWiz Plugin and Config Wizard
Version 2.0
March 2007
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

 Authors: edge     (Config Wizard) 
          loadman  (LEDWiz Plugin v2)
          swindus  (LEDWiz Plugin v1)

 Dowload: http://mala.arcadezentrum.com/plugins
 Support: http://forum.arcadecontrols.com

  Thanks: swindus, RandyT, headkaze
          (Check out the about page for more info!)

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

This plugin adds full LEDWiz support to the Mala frontend.

[1] Features
[2] New Install
[3] Upgrade
[4] Troubleshooting

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
[1] Features

The Mala LEDWiz Plugin was designed to be a simple but powerful tool to help light 
up your control panels.  We tried to make it as customizable as possible, and we
are always open for more suggestions.

In version 2 of the plugin and configuration wizard, you can...
- Support for up to 16 LEDWiz controllers
- Support for both RGB and Single Color LEDs
- As you scroll through games in Mala, light your LEDs based on player controls
- Flash all your buttons on Mala start, Mala exit, game start, gamelist change, etc.
- Support for ADMIN buttons:
    - User can assign friendly names to admin buttons (ie, Menu, Pause, etc)
    - User can make admin buttons stay lit (no matter what game is selected)
- Create lighting settings for every emulator supported by Mala (not just Mame)
- Over-ride default lighting settings for specific games
- FLASH-N-SPEAK - Plugin will flash and speak each control upon game launch
  (ie, JUMP, FIRE, etc)
- Random Attract Mode - When Mala goes into screensaver mode, the ledwiz plugin
  will randomly run one of the ledwiz animations (LWA) included [THANKS HK!]
- EZ-RGB Data Entry - To help speed up data entry when configuring your panel, 
  the config wizard will automatically populate the RGB values based on one input
  (for instance, if your RGB has its R wire in input 1, the plugin will
  automatically input G in input 2 and B in input 3)
- As you configurate your panel in the wizard, you can see your buttons lit up
  real time.  Make a change and instantly see it!
- And much more!

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
[2] New Install

- Run the self-extracting MalaLEDWizPluginv2.0.exe.

- When asked where to extract the folders, select your MALA directory 
  (ie, c:\mala).

- The install will create the following folders in your Mala directory:
  + LEDWiz Docs (this contains the documentation on the Mala LEDWiz plugin)
  + LEDWiz Installer (this contains the LEDWiz OCX)
  + plugins (this is where you can put all your cool Mala plugins)

- Go into the "LEDWiz Installer" directory and run "LEDWiz OCX.exe".  
  This will install the LEDWIz OCX that the Mala plugin needs to operate.

- Ok.  SO the plugin is installed... And the LEDWIz OCX is installed.  
  We are almost there.

- You now need to tell Mala how you wired all your LEDs/buttons.

- Go into your new plugins directory and run "ledwizard.exe".

- In The LEDWiz Config Wizard, you get to associate player controls 
  (ie, P1_BUTTON 1) with your LEDWiz & LEDs.  

- For instance, if my PLAYER 1 COIN RGB LED is wired into inputs 1,2,3 on my 
  LEDWiz, I would:
  + Select P1_COIN on the left listbox.
  + Be sure that P1_COIN is CHECKED.
  + Then select LED Type of RGB.
  + For R input, I would select 1.
  + For G input, I would select 2.
  + For B input, I would select 3.

- Configure the rest of your control panel accordingly.

- When done, click on SAVE.

- You will be asked what type of file you are saving.  Save your settings 
  as "Main Mala COnfiguration". This will create your ledwiz.cfg 
  (the main file used by the Mala LEDWiz plugin).

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
[3] Upgrade

- If you have version 1.0 of the Mala LEDWiz plugin already installed, you 
  need to delete the old version first.  Renaming the old ledwiz.mplugin file
  does not always work.  Delete it or move it to another directory.

- Run the self-extracting MalaLEDWizPluginv2.0.exe.

- When asked where to extract the folders, select your MALA directory
  (ie, c:\mala).

- The install will create the following folders in your Mala directory:
  + LEDWiz Docs (this contains the documentation on the Mala LEDWiz plugin)
  + LEDWiz Installer (this contains the LEDWiz OCX)
  + plugins (this is where you can put all your cool Mala plugins)

- Since you already had v1 of this plugin working, you do not need to reinstall 
  the LEDWIz OCX.

- Since we added many new features to v2 of the plugin, you need to re-run 
  the LEDwiz Config Wizard.

- Go into your plugins directory and run "ledwizard.exe".

- The Wizard will load in your v1 ledwiz.cfg file.   

- Update/change your settings accordingly.

- When done, click on SAVE.

- Save your settings as "Main Mala COnfiguration".
  This update your ledwiz.cfg to version 2.0

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
[4] Troubleshooting

If you do not have XP, you may need to install the Microsoft Text to Speech Reader.
It can be downloaded for free here:
http://www.microsoft.com/reader/developers/downloads/tts.asp

If you run into any problems, please post a message in the software forum 
at BYOAC:  http://forum.arcadecontrols.com.

Loadman and I live on those forums, so we'll be able to quickly help you out.
:-)

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=