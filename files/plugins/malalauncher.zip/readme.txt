Put the .mplugin file in your MaLa Plugins directory. The msvc files go in the
main MaLa directory on some systems and the plugins directory on others. Not
sure why it varies. Then create a directory called Launch in the Plugins
directory and put some shortcuts in there.

Enjoy!

- TheShanMan, a.k.a. Jeff Shanholtz