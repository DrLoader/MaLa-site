@echo off
SET BATCHPATH=C:\Programme\Emulation\Daphne0.99.6\roms\batchs
SET DAPHNE=C:\Programme\Emulation\Daphne0.99.6\daphne.exe

echo Starte: %1

IF %1==Astron_Belt_[Hitachi] %BATCHPATH%\Astron_Belt_[Hitachi].bat %DAPHNE%
IF %1==Astron_Belt_[Pioneer] %BATCHPATH%\Astron_Belt_[Pioneer].bat %DAPHNE%
IF %1==Badlands %BATCHPATH%\Badlands.bat %DAPHNE%
IF %1==Badlands_[re-encoded] %BATCHPATH%\Badlands_[re-encoded].bat %DAPHNE%
IF %1==Bega's_Battle %BATCHPATH%\Bega's_Battle.bat %DAPHNE%
IF %1==Cliff_Hanger %BATCHPATH%\Cliff_Hanger.bat %DAPHNE%
IF %1==Cliff_Hanger_[alternate] %BATCHPATH%\Cliff_Hanger_[alternate].bat %DAPHNE%
IF %1==Cobra_Command %BATCHPATH%\Cobra_Command.bat %DAPHNE%
IF %1==Esh's_Aurunmilla %BATCHPATH%\Esh's_Aurunmilla.bat %DAPHNE%
IF %1==Esh's_Aurunmilla_[alternate_ROMS1] %BATCHPATH%\Esh's_Aurunmilla_[alternate_ROMS1].bat %DAPHNE%
IF %1==Esh's_Aurunmilla_[alternate_ROMS2] %BATCHPATH%\Esh's_Aurunmilla_[alternate_ROMS2].bat %DAPHNE%
IF %1==Galaxy_Ranger %BATCHPATH%\Galaxy_Ranger.bat %DAPHNE%
IF %1==Galaxy_Ranger_[re-encoded] %BATCHPATH%\Galaxy_Ranger_[re-encoded].bat %DAPHNE%
IF %1==Goal_to_Go_[Side1] %BATCHPATH%\Goal_to_Go_[Side1].bat %DAPHNE%
IF %1==Goal_to_Go_[Side2] %BATCHPATH%\Goal_to_Go_[Side2].bat %DAPHNE%
IF %1==Star_Blazer %BATCHPATH%\Star_Blazer.bat %DAPHNE%
IF %1==Super_Don_Quix-ote %BATCHPATH%\Super_Don_Quix-ote.bat %DAPHNE%
IF %1==Super_Don_Quix-ote_[short_scenes] %BATCHPATH%\Super_Don_Quix-ote_[short_scenes].bat %DAPHNE%
IF %1==Thayer's_Quest %BATCHPATH%\Thayer's_Quest.bat %DAPHNE%