start/wait %1 astronp vldp -framefile E:\RomsundIsos\Arcade\Laserdisc\Astron_Belt\astron.txt -fullscreen -blank_skips -blank_searches

