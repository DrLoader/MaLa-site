- TYPE-R -

Scalable Horizontal @4:3 (1280x960)
Scalable Horizontal @16:9 (1920x1080)
Scalable Horizontal @16:10 (1600x1000)

Move the Microgramma font to your system fonts folder.

Includes 'Start', 'Exit', 'Info', and 'Menu' windows.

Includes 'Start', 'Click', and 'Exit' sounds.

Logo-free background images are included for each size.

Tuner logos are included in the 'Badges' folder.  To use these, place the logo on a logo-less background using an image editor.