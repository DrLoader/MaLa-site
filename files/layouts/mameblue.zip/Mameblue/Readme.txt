** Mameblue v1.0 by Avernus **


* This is a fixed layout at 1024x768 *


* Made with MaLa 1.5 *


* How to Install *


1 - Unzip to your mala layout folder.

2 - Run mala right click and open the GUI tab.

3 - Browse for the mameblue folder.

4 - Click ok and yer done, enjoy.


*USAGE POLICY*

Feel free to distribute without charge.

Aknowledge the Author if used outside
the MaLa site.

