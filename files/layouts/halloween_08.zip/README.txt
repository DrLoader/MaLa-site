Scalable (Created @1280 x 960).
Move the Curlz font to your system fonts if you dont have it.
The Video box is on top of the Snap/Titles box, if theres any confusion.
Includes 'Start', 'Exit', and other menus.
Bonus sounds: List movement, Start, and Exit.

PS, Back image was done by Radojavor.  Check out more of his work here:
http://radojavor.deviantart.com/