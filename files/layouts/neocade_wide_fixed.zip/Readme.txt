Neocade v1.0 by Bu2t

Installation

1. Install fonts
2. Copy neocade_wide_fixed folder and mll to the mala base directory
3. Set definables as shown in the definable.jpg
4. Enable "Layout files are located in a folder with the same name as the layout" under Options -> GUI -> Layout
5. Optional wallpaper for your cab if you autostart Mala
6. Apply layout

Credits

Shock_ for the Applesque layout. (http://malafe.net/index.php?page=layouts&subpage=applesque)
Neil Lockhart for the MAME marquee. (http://switchblaze.com/geekstuff.htm)
ShyFonts for the "SF Old Republic" font. (http://www.dafont.com/sf-old-republic.font)

