////////////////////////////////////
v549e version 1.1 - a MaLa layout
by shock_ - September 2007/2008

////////////////////////////////////
INFORMATION
A simple scalable layout to suit 4:3 aspect screens.

Designed to make use of hi-res cabinet photos, snaps and video.

One required freeware font included: "Enigmatic Unicode".

Photoshop file may be available; see Licence section below.

Made and tested using MaLa v1.0 RC9.

////////////////////////////////////
CHANGELOG

v549e
-- Caved to pressure and regenerated in 4:3 ratio.  No square menu with letterbox format!
-- Providing dedicated 640x480 and 1024x768 variants; the faux scanlines suck if you've got real ones at low res.
-- Rationalised fonts, now using Enigmatic Unicode.
-- General tidy-up

v54
-- Original release, available while stocks last at:
http://forum.arcadecontrols.com/index.php?topic=69785.msg713022#msg713022


////////////////////////////////////
INSTRUCTIONS


1. Install the font in your Windows fonts folder
[ Open the enclosed .zip file and extract the .ttf files to %windir%\fonts\ ]


2. Save to disk
Copy the rest of the files in this package to your preferred disk location, e.g. c:\mala\layouts\


3. Set definable 1
Open MaLa and access the Options menu. Under the Mame Config tab, select
the Pictures and Videos sub-tab and ensure Definable 1 is referencing the
location of your cabinet image collection.  You do have a collection, right?

Also ensure your snaps and video paths are correct, and your gamelists are
configured.


4. Select layout
Again in the MaLa options menu, select the GUI tab.  Under the Layout sub-tab,
ensure the Layout Folder is set to wherever you saved the files in step 2.
Choose your preferred screen resolution variant (640x480 or 1024x768) from the selection box.

Also ensure you have un-checked the "Use layout names for directory names" box.


Optional:
Should you wish to display cabinets for emulators other than MAME, you will need to perform
a little hack.  Open the 640x480.mll or 1024x768 file in MaLa Layout and enable the "Marquee" for both
vertical and horizontal views, and disable Definable 1.  In MaLa, set the Marquee location 
for each emulator to point to the relevant directory for your machine photos.  The obvious 
downside is that the Info Window will then display your machine under the Marquee screen.

The whole point of this is to circumvent the lack of definables for emulators other than MAME.
I use this for pinballs to great effect.


////////////////////////////////////
LICENCE
My original work within this package is released to the public domain.

Licence conditions for the font packaged alongside my work are available within
the readme file accompanying those fonts or encoded into the truetype files themselves.

Please mention me as the originator of this work when making it publicly available
e.g. for download from your website, or if you make a derivative work based on this,
e.g. porting to another front end.

Source PSD has been published to a free file hosting service.  I can make no guarantees it will last there forever.
http://ifile.it/ndi3kb/version5.4.9e.7z