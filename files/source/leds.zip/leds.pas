unit leds;

interface

uses classes, windows, Sysutils, Dialogs, forms, header;

{******************************************************************************}
type
  TLEDAttractMode = class(TObject)
  private
    { Private-Deklarationen }
  public
    { Public-Deklarationen }
    FName:                 string;
    FDuration:             Integer;
    FLedState:             array [0..LED_MAX] of Integer;

    constructor Create; overload;
    destructor Destroy; override;

    procedure Save(writer : TWriter); virtual;
    procedure Load(reader : TReader); virtual;

end;

{******************************************************************************}
type
  TLEDAttractModeList = class(TObject)
  private
    { Private-Deklarationen }

  public
    { Public-Deklarationen }

    FLEDAttractModes:                TList;

    FLEDAttractModeCount:            Integer;

    constructor Create();
    destructor Destroy; override;

    procedure Save(writer : TWriter); virtual;
    procedure Load(reader : TReader); virtual;

    procedure Clear;
    function Add(ALEDAttractMode: TLEDAttractMode): Integer;
    function Insert(AIndex: Integer; ALEDAttractMode: TLEDAttractMode): Integer;
    procedure Remove(AIndex: Integer);
    function Count: Integer;
    function GetCopy(AIndex: Integer): TLEDAttractMode;

    procedure Sort(SortField: Integer);

    function GetAsStrings: TStringList;
    
end;

{******************************************************************************}
type
  TLEDConfig = class(TObject)
  private
    { Private-Deklarationen }
  public
    { Public-Deklarationen }

    // Count of connected LEDs/warrior boards
    // HW_LED_16 = 16;
    // HW_LED_32 = 32;
    // HW_LED_48 = 48;
    // HW_LED_64 = 64;
    FHWLeds:               Integer;

    // Assoziation Led - Button
    FLeds:                 array [0..LED_MAX] of Integer;

    FShowCoins:            Boolean;
    FShowStart:            Boolean;
    FShowButtons:          Boolean;

    FLEDAttractModes:         TLEDAttractModeList;
    
    constructor Create; overload;
    destructor Destroy; override;

    procedure Save(writer : TWriter); virtual;
    procedure Load(reader : TReader); virtual;

    function GetLEDNumber(ALED: Integer): Integer;
    procedure CreateRandomized(ALength, AMinuration, AMaxDuration: Integer);

end;

implementation

{ TLEDAttractMode }

{*******************************************************************************
*
*******************************************************************************}
constructor TLEDAttractMode.Create;
var
   i: Integer;
begin
    FName := '';
    FDuration := 500;
    for i := 0 to LED_MAX do begin
        FLedState[i] := LED_OFF;
    end;
end;

{*******************************************************************************
*
*******************************************************************************}
destructor TLEDAttractMode.Destroy;
begin
     inherited;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDAttractMode.Load(reader: TReader);
var
   i: Integer;
begin
     try
         with reader do begin
              ReadListBegin;
              while not EndOfList do begin

                  FName := ReadString;
                  FDuration := ReadInteger;

                  for i := 0 to LED_MAX do begin
                      FLedState[i] := ReadInteger;
                  end;
                  
              end;
              ReadListEnd;
         end;
     except
           Application.MessageBox('Error reading led config file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDAttractMode.Save(writer: TWriter);
var
   i: Integer;
begin
     try
         with writer do begin

              WriteListBegin;

              WriteString(FName);
              WriteInteger(FDuration);

              for i := 0 to LED_MAX do begin
                  WriteInteger(FLedState[i]);
              end;

              WriteListEnd;
         end;
     except
           Application.MessageBox('Error writing led config file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{ TLCDScreenList }

{*******************************************************************************
*
*******************************************************************************}
function CompareByName(Item1, Item2: Pointer): Integer;
begin
   Result := CompareText(TLEDAttractMode(Item1).FName, TLEDAttractMode(Item2).FName);
end;

{*******************************************************************************
*
*******************************************************************************}
function TLEDAttractModeList.Add(ALEDAttractMode: TLEDAttractMode): Integer;
var
   nr: Integer;
begin
     nr := FLEDAttractModes.Add(ALEDAttractMode);
     FLEDAttractModeCount := FLEDAttractModes.Count;
     Result := nr;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDAttractModeList.Clear;
var
   i: Integer;
begin
    for i := 0 to FLEDAttractModes.Count - 1 do
    begin
         TLEDAttractMode(FLEDAttractModes.Items[i]).Destroy;
    end;
    FLEDAttractModes.Destroy;
    FLEDAttractModes := TList.Create;
    FLEDAttractModeCount := FLEDAttractModes.Count;
end;

{*******************************************************************************
*
*******************************************************************************}
function TLEDAttractModeList.Count: Integer;
begin
     Result := FLEDAttractModes.Count;
end;

{*******************************************************************************
*
*******************************************************************************}
constructor TLEDAttractModeList.Create;
begin
    FLEDAttractModes := TList.Create;
    FLEDAttractModeCount := FLEDAttractModes.Count;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDConfig.CreateRandomized(ALength, AMinuration, AMaxDuration: Integer);
var
   i, length: Integer;
   new_attractmode: TLEDAttractMode;
begin
     FLEDAttractModes.FLEDAttractModes.Clear;
     length := 0;
     while length < ALength do begin
           new_attractmode := TLEDAttractMode.Create;
           new_attractmode.FDuration := AMinuration + Random(AMaxDuration - AMinuration);
           length := length + new_attractmode.FDuration;
           if length > ALength then new_attractmode.FDuration :=  new_attractmode.FDuration - (ALength -length);
           for i := 0 to LED_MAX do begin
               if FLeds[i] <> LED_NOTUSED then begin
                  new_attractmode.FLedState[i] := Random(2);
               end;
           end;
           FLEDAttractModes.Add(new_attractmode);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
destructor TLEDAttractModeList.Destroy;
var
   i: Integer;
begin
    for i := 0 to FLEDAttractModes.Count - 1 do
    begin
         if FLEDAttractModes.Items[i] <> nil then
            TLEDAttractMode(FLEDAttractModes.Items[i]).Destroy;
    end;
    FLEDAttractModes.Destroy;
    inherited;
end;

{*******************************************************************************
*
*******************************************************************************}
function TLEDAttractModeList.GetAsStrings: TStringList;
var
   i: Integer;
   names: TStringList;
begin
     names := TStringList.Create;
     for i:= 0 to FLEDAttractModes.Count - 1 do begin
         names.Add(TLEDAttractMode(FLEDAttractModes.Items[i]).FName);
     end;

     Result := names;
end;

{*******************************************************************************
*
*******************************************************************************}
function TLEDAttractModeList.GetCopy(AIndex: Integer): TLEDAttractMode;
var
   state: TLEDAttractMode;
   i: Integer;
begin
     state := TLEDAttractMode.Create;
     state.FName := TLEDAttractMode(FLEDAttractModes.Items[AIndex]).FName;
     state.FDuration := TLEDAttractMode(FLEDAttractModes.Items[AIndex]).FDuration;
     for i := 0 to LED_MAX do begin
         state.FLedState[i] := TLEDAttractMode(FLEDAttractModes.Items[AIndex]).FLedState[i];
     end;
     Result := state;
end;

{*******************************************************************************
*
*******************************************************************************}
function TLEDAttractModeList.Insert(AIndex: Integer;
  ALEDAttractMode: TLEDAttractMode): Integer;
begin
     FLEDAttractModes.Insert(AIndex, ALEDAttractMode);
     FLEDAttractModeCount := FLEDAttractModes.Count;
     Result := AIndex;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDAttractModeList.Load(reader: TReader);
var
   i: Integer;
   newattractmode: TLEDAttractMode;
begin
     try
         with reader do begin
              ReadListBegin;
              while not EndOfList do begin

                    FLEDAttractModeCount := ReadInteger;

              end;
              ReadListEnd;
         end;

        FLEDAttractModes.Clear;

        for i := 0 to FLEDAttractModeCount - 1 do
        begin
             newattractmode := TLEDAttractMode.Create;
             newattractmode.Load(reader);
             FLEDAttractModes.Add(newattractmode);
        end;
     except
           Application.MessageBox('Error reading attract mode file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDAttractModeList.Remove(AIndex: Integer);
begin
     FLEDAttractModes.Delete(AIndex);
     FLEDAttractModes.Capacity := FLEDAttractModes.Count;
     FLEDAttractModeCount := FLEDAttractModes.Count;

end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDAttractModeList.Save(writer: TWriter);
var
   i: Integer;
begin
     try
         with writer do begin
              WriteListBegin;

              WriteInteger(FLEDAttractModeCount);

              WriteListEnd;
         end;

         for i := 0 to FLEDAttractModeCount - 1 do
         begin
              TLEDAttractMode(FLEDAttractModes.Items[i]).Save(writer);
         end;
     except
           Application.MessageBox('Error writung attract mode file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDAttractModeList.Sort(SortField: Integer);
begin
     case SortField of
     0: FLEDAttractModes.Sort(@CompareByName);
     end;
end;

{ TLEDConfig }

{*******************************************************************************
*
*******************************************************************************}
constructor TLEDConfig.Create;
var
   i: Integer;
begin
      FHWLeds := HW_LED_16_M;
      for i := 0 to LED_MAX do begin
          FLeds[i] := LED_NOTUSED;
      end;
      FLEDAttractModes := TLEDAttractModeList.Create;
end;

{*******************************************************************************
*
*******************************************************************************}
destructor TLEDConfig.Destroy;
begin
     FLEDAttractModes.Destroy;
  inherited;
end;

{*******************************************************************************
*
*******************************************************************************}
function TLEDConfig.GetLEDNumber(ALED: Integer): Integer;
var
   i: Integer;
begin
     result := -1;
     for i := 0 to LED_MAX do begin
         if FLeds[i] = ALED then result := i;
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDConfig.Load(reader: TReader);
var
   i: Integer;
begin
     try
         with reader do begin
              ReadListBegin;
              while not EndOfList do begin

                  FHWLeds := ReadInteger;

                  for i := 0 to LED_MAX do begin
                      FLeds[i] := ReadInteger;
                  end;


                  FShowCoins := ReadBoolean;
                  FShowStart := ReadBoolean;
                  FShowButtons := ReadBoolean;
              end;


              ReadListEnd;

         end;

         FLEDAttractModes.Load(reader);

     except
           Application.MessageBox('Error reading attract mode file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TLEDConfig.Save(writer: TWriter);
var
   i: Integer;
begin
     try
         with writer do begin
              WriteListBegin;

              WriteInteger(FHWLeds);

              for i := 0 to LED_MAX do begin
                  WriteInteger(FLeds[i]);
              end;

              WriteBoolean(FShowCoins);
              WriteBoolean(FShowStart);
              WriteBoolean(FShowButtons);

              WriteListEnd;
         end;

         FLEDAttractModes.Save(writer);

     except
           Application.MessageBox('Error writung attract mode file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

end.
