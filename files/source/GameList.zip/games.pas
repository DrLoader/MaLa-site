unit games;

interface

uses classes, windows, Sysutils, LibXmlComps, LibXmlParser, Dialogs, header, inifiles,
     forms, ShlObj, ActiveX, FindFile;

{******************************************************************************}
type
  TGame = class(TObject)
  private
    { Private-Deklarationen }
  public
    { Public-Deklarationen }

    FName:                 string;       // rom name
    FRomOf:                string;       // master oder bios name
    FCloneOf:              string;       // master rom name
    FSourcefile:           string;       // driver name

    FDescription:          string;       // game title
    FYear:                 Integer;      // year
    FManufacturer:         string;       // manufacturer
    FGenre:                string;       // game genre

    FInputButtons:         Integer;      // control panel button count
    FInputCoins:           Integer;      // control panel coin count
    FInputPlayers:         string;       // player count, nplayers information
    FInputControl:         string;       // kind of game control

    FVideoScreen:          string;       // kind of video screen
    FVideoOrientation:     string;       // vertical or horizontal
    FVideoWidth:           Integer;      // width of the screen
    FVideoHeight:          Integer;      // height of the screen

    FDriverStatus:         string;
    FDriverColor:          string;
    FDriverSound:          string;
    FDriverEmulation:      string;
    FDriverGraphic:        string;

    FControls:             string;       // game controls from controls.dat
    FJoyUp:                string;
    FJoyDown:              string;
    FJoyLeft:              string;
    FJoyRight:             string;
    FButton1:              string;
    FButton2:              string;
    FButton3:              string;
    FButton4:              string;
    FButton5:              string;
    FButton6:              string;
    FButton7:              string;
    FButton8:              string;
    FDetails:              string;

    FRomPath:              string;       // path of romfile
    FExtension:            string;       // extension of romfile

    FPlayed:               Integer;     // Number of times played (this can be reset in Gui)

    constructor Create; overload;
    destructor Destroy; override;

    procedure Save(writer : TWriter); virtual;
    procedure Load(reader : TReader); virtual;

end;

{******************************************************************************}
type
  TGameList = class(TObject)
  private
    { Private-Deklarationen }
    XmlScanner:             TXmlScanner;
    TheGame:                TGame;
    AddTheGame:             Boolean;
    CurrentElement:         Integer;
    GameCompleted:          Boolean;

    SearchMameRoms:         Boolean;
    CurrentFolder:          string;
    CurrentRom:             string;
    CurrentExt:             string;

    FMameVersion:           Integer;

    readtxt: Boolean;
    readlnk: Boolean;
    txtfile: TStringList;

    xml_file, cat_file:     TStringList;
    controls_file, nplayers_file:          TIniFile;

    FGameControls: TMameControls;        // controls.ini values of game

    procedure XmlScannerXmlProlog(Sender: TObject; XmlVersion, Encoding: String; Standalone: Boolean);
    procedure XmlScannerPI(Sender: TObject; Target, Content: String; Attributes: TAttrList);
    procedure XmlScannerStartTag(Sender: TObject; TagName: String; Attributes: TAttrList);
    procedure XmlScannerEndTag(Sender: TObject; TagName: String);
    procedure XmlScannerEmptyTag(Sender: TObject; TagName: String; Attributes: TAttrList);
    procedure XmlScannerComment(Sender: TObject; Comment: String);
    procedure XmlScannerContent(Sender: TObject; Content: String);
    procedure XmlScannerDtdRead(Sender: TObject; RootElementName: String);

  public
    { Public-Deklarationen }

    FName:                 string;
    FAutor:                string;
    FCreated:              TDateTime;
    FModified:             TDateTime;
    FComment:              string;
    FWriteProtected:       Boolean;

    // VoiceList
    FGames:                TList;

    FGameCount:            Integer;
    FSortField:            Integer;

    constructor Create();
    destructor Destroy; override;

    procedure Save(writer : TWriter); virtual;
    procedure Load(reader : TReader); virtual;

    procedure Clear;
    procedure Add(AGame: TGame);
    procedure Remove(AIndex: Integer);
    function Count: Integer;

    procedure BuildFromXMLFile(XMLFile, CatverFile, ControlsFile, NPlayersFile: string);
    procedure BuildFromDirectoryContent(APath, AExtension: string; SearchSubFolders: Boolean);
    procedure Sort(SortField: Integer);

    procedure GetGameControls(ARomName, AMasterName: string);
    function GetNPlayersEntry(ARomName, AMasterName: string): string;

    function GetCopy(AIndex: Integer): TGame;
    function GetBios(AIndex: Integer): string;
    function GetName(AIndex: Integer): string;
    function GetDescription(AIndex: Integer): string;
    function GetIndexFromName(AName: string): Integer;
    function GetIndexFromLetter(ALetter: string): Integer;
    function IsGameInList(AName: string): Boolean;
    function IsMaster(AIndex: Integer): Boolean;

    function GetAsStrings: TStringList;

    procedure FindFileFound(Sender: TObject; Folder: String; var FileInfo: TSearchRec);
    procedure FindFileNewFolder(Sender: TObject; Folder: String; var IgnoreFolder: Boolean);

end;

const
     _MAME = 'mame';

     _GAME = 'game';
     _DESCRIPTION = 'description';
     _YEAR = 'year';
     _MANUFACTURER = 'manufacturer';

     _VIDEO106 = 'video';
     _VIDEO107 = 'display';

     _INPUT = 'input';
     _CONTROL = 'control';

     _DRIVER = 'driver';

     ELEMENT_NONE = 0;
     ELEMENT_DESCRIPTION = 1;
     ELEMENT_YEAR = 2;
     ELEMENT_MANUFACTURER = 3;
     ELEMENT_VIDEO = 4;
     ELEMENT_INPUT = 5;
     ELEMENT_DRIVER = 6;
     ELEMENT_CONTROL = 7;
     ELEMENT_MAME = 8;

     CRLF = ^M^J;

implementation

uses main;

{*******************************************************************************
* GetTarget
*******************************************************************************}
function GetTarget(const LinkFileName:String): String;
var
   //Link : String;
   psl  : IShellLink;
   ppf  : IPersistFile;
   WidePath  : Array[0..260] of WideChar;
   Info      : Array[0..MAX_PATH] of Char;
   wfs       : TWin32FindData;
   command: string;
begin
  if UpperCase(ExtractFileExt(LinkFileName)) <> '.LNK' Then
  begin
    Result:='NOT a shortuct by extension!';
    Exit;
  end;

  CoCreateInstance(CLSID_ShellLink, nil, CLSCTX_INPROC_SERVER, IShellLink, psl);
  if psl.QueryInterface(IPersistFile, ppf) = 0 Then
  Begin
    MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, PChar(LinkFileName), -1, @WidePath, MAX_PATH);
    ppf.Load(WidePath, STGM_READ);
    // get app path and name
    psl.GetPath(@info, MAX_PATH, wfs, SLGP_UNCPRIORITY);
    command := info;
    psl.GetArguments(@info, MAX_PATH);
    command := command + ' ' + info;
    Result := command;
  end
  else
    Result := '';
end;


{ TGame }

{*******************************************************************************
*
*******************************************************************************}
constructor TGame.Create;
begin
    FName := '';
    FRomOf := '';
    FCloneOf := '';
    FSourcefile := '';

    FDescription := '';
    FYear := 0;
    FManufacturer := '';
    FGenre := '';

    FInputButtons := 0;
    FInputCoins := 0;
    FInputPlayers := '';
    FInputControl := '';

    FVideoScreen := '';
    FVideoOrientation := '';
    FVideoWidth := 0;
    FVideoHeight := 0;

    FDriverStatus := '';
    FDriverColor := '';
    FDriverSound := '';
    FDriverEmulation := '';
    FDriverGraphic := '';

    FControls := '';
    FJoyUp := '';
    FJoyDown := '';
    FJoyLeft := '';
    FJoyRight := '';
    FButton1 := '';
    FButton2 := '';
    FButton3 := '';
    FButton4 := '';
    FButton5 := '';
    FButton6 := '';
    FButton7 := '';
    FButton8 := '';
    FDetails := '';

    FRomPath := '';
    FExtension := '';

    FPlayed := 0;
end;

{*******************************************************************************
*
*******************************************************************************}
destructor TGame.Destroy;
begin
  inherited;
     //
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGame.Load(reader: TReader);
begin
     try
         with reader do begin
              ReadListBegin;
              while not EndOfList do begin

                  FName := ReadString;
                  FRomOf := ReadString;
                  FCloneOf := ReadString;
                  FSourcefile := ReadString;

                  FDescription := ReadString;
                  FYear := ReadInteger;
                  FManufacturer := ReadString;
                  FGenre := ReadString;

                  FInputButtons := ReadInteger;
                  FInputCoins := ReadInteger;
                  FInputPlayers := ReadString;
                  FInputControl := ReadString;

                  FVideoScreen := ReadString;
                  FVideoOrientation := ReadString;
                  FVideoWidth := ReadInteger;
                  FVideoHeight := ReadInteger;

                  FDriverStatus := ReadString;
                  FDriverColor := ReadString;
                  FDriverSound := ReadString;
                  FDriverEmulation := ReadString;
                  FDriverGraphic := ReadString;

                  FControls := ReadString;
                  FJoyUp := ReadString;
                  FJoyDown := ReadString;
                  FJoyLeft := ReadString;
                  FJoyRight := ReadString;
                  FButton1 := ReadString;
                  FButton2 := ReadString;
                  FButton3 := ReadString;
                  FButton4 := ReadString;
                  FButton5 := ReadString;
                  FButton6 := ReadString;
                  FButton7 := ReadString;
                  FButton8 := ReadString;
                  FDetails := ReadString;

                  FRomPath := ReadString;
                  FExtension := ReadString;
                  
                  FPlayed := ReadInteger;

              end;
              ReadListEnd;
         end;
     except
           Application.MessageBox('Error reading game list file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGame.Save(writer: TWriter);
begin
     try
         with writer do begin
              WriteListBegin;

              WriteString(FName);
              WriteString(FRomOf);
              WriteString(FCloneOf);
              WriteString(FSourcefile);

              WriteString(FDescription);
              WriteInteger(FYear);
              WriteString(FManufacturer);
              WriteString(FGenre);

              WriteInteger(FInputButtons);
              WriteInteger(FInputCoins);
              WriteString(FInputPlayers);
              WriteString(FInputControl);

              WriteString(FVideoScreen);
              WriteString(FVideoOrientation);
              WriteInteger(FVideoWidth);
              WriteInteger(FVideoHeight);

              WriteString(FDriverStatus);
              WriteString(FDriverColor);
              WriteString(FDriverSound);
              WriteString(FDriverEmulation);
              WriteString(FDriverGraphic);

              WriteString(FControls);
              WriteString(FJoyUp);
              WriteString(FJoyDown);
              WriteString(FJoyLeft);
              WriteString(FJoyRight);
              WriteString(FButton1);
              WriteString(FButton2);
              WriteString(FButton3);
              WriteString(FButton4);
              WriteString(FButton5);
              WriteString(FButton6);
              WriteString(FButton7);
              WriteString(FButton8);
              WriteString(FDetails);

              WriteString(FRomPath);
              WriteString(FExtension);

              WriteInteger(FPlayed);

              WriteListEnd;
         end;
     except
           Application.MessageBox('Error writing game list file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{ TGameList }

{*******************************************************************************
*
*******************************************************************************}
function CompareByName(Item1, Item2: Pointer): Integer;
begin
   Result := CompareText(TGame(Item1).FName, TGame(Item2).FName);
end;

{*******************************************************************************
*
*******************************************************************************}
function CompareByDescription(Item1, Item2: Pointer): Integer;
begin
   Result := CompareText(TGame(Item1).FDescription, TGame(Item2).FDescription);
end;

{*******************************************************************************
*
*******************************************************************************}
function CompareByGenre(Item1, Item2: Pointer): Integer;
begin
   Result := CompareText(TGame(Item1).FGenre + TGame(Item1).FDescription, TGame(Item2).FGenre + TGame(Item2).FDescription);
end;

{*******************************************************************************
*
*******************************************************************************}
function CompareByPlayed(Item1, Item2: Pointer): Integer;
var
   count1, count2: string;
begin
     count1 := Format('%.6d', [999999 - TGame(Item1).FPlayed]);
     count1 := count1 + TGame(Item1).FDescription;
     count2 := Format('%.6d', [999999 - TGame(Item2).FPlayed]);
     count2 := count2 + TGame(Item2).FDescription;
     Result := CompareText(count1, count2);
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.Add(AGame: TGame);
begin
     FGames.Add(AGame);
     FGameCount := FGames.Count;
end;

{*******************************************************************************
*
* Creates a gamelist from directory content
* AExtension can be a comma separated list of extension
* If the loaded file is a TXT file, the first line of this file is used as game description
*
*******************************************************************************}
procedure TGameList.BuildFromDirectoryContent(APath, AExtension: string; SearchSubFolders: Boolean);
var
   Path, Ext : string;
   AllExtensions: TStringList;
   i : Integer;

begin
    SearchMameRoms := False;

    readtxt := false;
    readlnk := false;

    frmMain.Log(mtInfo, 'BuildFromDirectoryContent');
    frmMain.Log(mtInfo, 'Using root path: ' + APath);


    TheGame := nil;
    FGames.Clear;

    AllExtensions := TStringList.Create;
    AllExtensions.CommaText := AExtension;

    for i := 0 to AllExtensions.Count - 1 do begin
        Ext := '*.' + AllExtensions.Strings[i];
        CurrentExt := AllExtensions.Strings[i];

        frmMain.Log(mtInfo, 'Using extension: ' + Ext);

        // read in first line of txt file (zinc)?
        if UpperCase(AExtension) = 'TXT' then readtxt := true;

        // read in target from link file (lnk)?
        if UpperCase(AExtension) = 'LNK' then readlnk := true;

        Path := IncludeTrailingBackslash(APath);
        CurrentFolder := Path;

        frmMain.FindRom.OnFound := FindFileFound;
        frmMain.FindRom.OnNewFolder := FindFileNewFolder;
        frmMain.FindRom.Filename := Ext;
        frmMain.FindRom.Attributes := [ffArchive, ffReadonly];
        frmMain.FindRom.Subfolders := SearchSubFolders;
        frmMain.FindRom.ExactAttribute := False;
        frmMain.FindRom.Location := Path;
        frmMain.FindRom.Execute;

    end;
    
    AllExtensions.Free;
end;

{*******************************************************************************
*
* Creates a gamelist from a mame XML file
*
*******************************************************************************}
procedure TGameList.BuildFromXMLFile(XMLFile, CatverFile, ControlsFile, NPlayersFile: string);
begin
     SearchMameRoms := True;

        frmMain.Log(mtInfo, 'BuildFromXMLFile: Creating Game list from XML File');

     // load xml data
     frmMain.Log(mtInfo, 'Loading mame XML File');
     xml_file := TStringList.Create;
     try
        xml_file.LoadFromFile(XMLFile);
     except
           Application.MessageBox('Error opening mame xml file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
           exit;
     end;

     // load catver data
     frmMain.Log(mtInfo, 'Loading catver.ini File');
     cat_file := TStringList.Create;
     try
        if CatverFile <> '' then cat_file.LoadFromFile(CatverFile)
        else  begin
        //      Application.MessageBox('No catver.ini file set!', PChar(APP_NAME), MB_OK + MB_ICONWARNING);
              frmMain.Log(mtError, 'BuildFromXMLFile: No catver.ini file set!');
              end;
     except
           Application.MessageBox('Error opening catver.ini file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
           exit;
      end;

     // load controls data
     frmMain.Log(mtInfo, 'Loading controls.ini data');
     try
         controls_file := nil;
         if (ControlsFile <> '') then begin
            if FileExists(ControlsFile) then begin
               controls_file := TIniFile.Create(ControlsFile);
            end;
         end
         else  Begin
               Application.MessageBox('No controls.ini file set!', PChar(APP_NAME), MB_OK + MB_ICONWARNING);
               frmMain.Log(mtError, 'BuildFromXMLFile: No controls.ini file set!');
               end;
     except
           Application.MessageBox('Error opening controls.ini file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
           exit;
     end;

     // load nplayers data
     frmMain.Log(mtInfo, 'Loading nplayers.ini data');
     try
         nplayers_file := nil;
         if (NPlayersFile <> '') then begin
            if FileExists(NPlayersFile) then begin
               nplayers_file := TIniFile.Create(NPlayersFile);
            end;
         end
          else Begin
            //   Application.MessageBox('No nplayers.ini file set!', PChar(APP_NAME), MB_OK + MB_ICONWARNING);
               frmMain.Log(mtError, 'BuildFromXMLFile: No nplayers.ini file set!');
               end;
     except
           Application.MessageBox('Error opening nplayers.ini file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
           exit;
     end;

     // clear game list
     Clear;

     // parse xml file
     try

        TheGame := nil;
        XmlScanner := TXmlScanner.Create(nil);
        XmlScanner.OnXmlProlog := XmlScannerXmlProlog;
        XmlScanner.OnPI := XmlScannerPI;
        XmlScanner.OnStartTag := XmlScannerStartTag;
        XmlScanner.OnEndTag := XmlScannerEndTag;
        XmlScanner.OnEmptyTag := XmlScannerEmptyTag;
        XmlScanner.OnComment := XmlScannerComment;
        XmlScanner.OnContent := XmlScannerContent;
        XmlScanner.OnDtdRead := XmlScannerDtdRead;
        XmlScanner.Filename := XMLFile;

          frmMain.Log(mtInfo, 'Starting game search');
          frmMain.Log(mtInfo, 'Using xml file: ' + XMLFile);
          XmlScanner.Execute;
          frmMain.Log(mtInfo, 'Finished game search');

     finally
            XmlScanner.Destroy;
     end;
        frmMain.Log(mtInfo, 'Finished Game list from XML File');
     xml_file.Free;
     cat_file.Free;
     controls_file.Free;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.Clear;
var
   i: Integer;
begin
    for i := 0 to FGames.Count - 1 do
    begin
         TGame(FGames.Items[i]).Destroy;
    end;
    FGames.Destroy;
    FGames := TList.Create;
    FGameCount := FGames.Count;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.Count: Integer;
begin
     Result := FGames.Count;
end;

{*******************************************************************************
*
*******************************************************************************}
constructor TGameList.Create;
begin
    FName := GAMELIST_ALLGAMES;
    FAutor := '';
    FCreated := now;
    FModified := now;

    FGames := TList.Create;
    FGameCount := FGames.Count;

    FSortField := SORT_DESCRIPTION;

    //XmlScanner := nil;
    FMameVersion := 0;
    TheGame := nil;
    AddTheGame := true;
    CurrentElement := ELEMENT_NONE;
end;

{*******************************************************************************
*
*******************************************************************************}
destructor TGameList.Destroy;
var
   i: Integer;
begin
    for i := 0 to FGames.Count - 1 do
    begin
         if FGames.Items[i] <> nil then
            TGame(FGames.Items[i]).Destroy;
    end;
    FGames.Destroy;
    inherited;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.GetCopy(AIndex: Integer): TGame;
var
   game: TGame;
begin
     if AIndex < FGames.Count then begin

         game := TGame.Create;

         game.FName := TGame(FGames.Items[AIndex]).FName;
         game.FCloneOf := TGame(FGames.Items[AIndex]).FCloneOf;
         game.FRomOf := TGame(FGames.Items[AIndex]).FRomOf;
         game.FSourcefile := TGame(FGames.Items[AIndex]).FSourcefile;

         game.FDescription := TGame(FGames.Items[AIndex]).FDescription;
         game.FYear := TGame(FGames.Items[AIndex]).FYear;
         game.FManufacturer := TGame(FGames.Items[AIndex]).FManufacturer;
         game.FGenre := TGame(FGames.Items[AIndex]).FGenre;

         game.FInputButtons := TGame(FGames.Items[AIndex]).FInputButtons;
         game.FInputCoins := TGame(FGames.Items[AIndex]).FInputCoins;
         game.FInputPlayers := TGame(FGames.Items[AIndex]).FInputPlayers;
         game.FInputControl := TGame(FGames.Items[AIndex]).FInputControl;

         game.FVideoScreen := TGame(FGames.Items[AIndex]).FVideoScreen;
         game.FVideoOrientation := TGame(FGames.Items[AIndex]).FVideoOrientation;
         game.FVideoWidth := TGame(FGames.Items[AIndex]).FVideoWidth;
         game.FVideoHeight := TGame(FGames.Items[AIndex]).FVideoHeight;

         game.FDriverStatus := TGame(FGames.Items[AIndex]).FDriverStatus;
         game.FDriverColor := TGame(FGames.Items[AIndex]).FDriverColor;
         game.FDriverSound := TGame(FGames.Items[AIndex]).FDriverSound;
         game.FDriverEmulation := TGame(FGames.Items[AIndex]).FDriverEmulation;
         game.FDriverGraphic := TGame(FGames.Items[AIndex]).FDriverGraphic;

         game.FControls := TGame(FGames.Items[AIndex]).FControls;
         game.FJoyUp := TGame(FGames.Items[AIndex]).FJoyUp;
         game.FJoyDown := TGame(FGames.Items[AIndex]).FJoyDown;
         game.FJoyLeft := TGame(FGames.Items[AIndex]).FJoyLeft;
         game.FJoyRight := TGame(FGames.Items[AIndex]).FJoyRight;
         game.FButton1 := TGame(FGames.Items[AIndex]).FButton1;
         game.FButton2 := TGame(FGames.Items[AIndex]).FButton2;
         game.FButton3 := TGame(FGames.Items[AIndex]).FButton3;
         game.FButton4 := TGame(FGames.Items[AIndex]).FButton4;
         game.FButton5 := TGame(FGames.Items[AIndex]).FButton5;
         game.FButton6 := TGame(FGames.Items[AIndex]).FButton6;
         game.FButton7 := TGame(FGames.Items[AIndex]).FButton7;
         game.FButton8 := TGame(FGames.Items[AIndex]).FButton8;
         game.FDetails := TGame(FGames.Items[AIndex]).FDetails;

         game.FRomPath := TGame(FGames.Items[AIndex]).FRomPath;
         game.FExtension := TGame(FGames.Items[AIndex]).FExtension;

         game.FPlayed := TGame(FGames.Items[AIndex]).FPlayed;

         Result := game;
     end
     else begin
          Result := nil;
     end;

end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.GetIndexFromName(AName: string): Integer;
var
   i: Integer;
   index: Integer;
begin
     index := -1;
     for i:= 0 to FGames.Count - 1 do begin
         if TGame(FGames.Items[i]).FName = AName then begin
            index := i;
            Break;
         end;
     end;

     Result := index;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.GetIndexFromLetter(ALetter: string): Integer;
var
   i: Integer;
   index: Integer;
begin
     index := -1;
     for i:= 0 to FGames.Count - 1 do begin
         if UpperCase(Copy(TGame(FGames.Items[i]).FDescription, 1, 1)) = UpperCase(ALetter) then begin
            index := i;
            Break;
         end;
     end;

     Result := index;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.IsGameInList(AName: string): Boolean;
var
   i: Integer;
   InList: Boolean;
begin
     InList := false;
     for i:= 0 to FGames.Count - 1 do begin
         if TGame(FGames.Items[i]).FName = AName then begin
            InList := true;
            Break;
         end;
     end;

     Result := InList;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.IsMaster(AIndex: Integer): Boolean;
var
   game: TGame;
begin
     if AIndex = -1 then begin
        Result := false;
        exit;
     end;
     game := FGames.Items[AIndex];
     if game.FCloneOf = '' then
        Result := true
     else
         Result := false;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.GetBios(AIndex: Integer): string;
var
   bios: string;
   game: TGame;
begin
     if AIndex = -1 then begin
        Result := '';
        exit;
     end;

     game := FGames.Items[AIndex];
     bios := '';
     // master without bios: cloneof = '', romof = ''
     // <game name="halleys" sourcefile="halleys.c">
     //
     if (game.FCloneOf = '') and (game.FRomOf = '') and (game.FSourcefile <> '') then begin
        // Capcom CPS-1
        if game.FSourcefile = 'cps1.c' then
           bios := 'cps1'
        // Capcom CPS-2
        else if game.FSourcefile = 'cps2.c' then
             bios := 'cps2'
        else
            bios := '';
     end
     // clone: cloneof = master, romof = master
     // <game name="halleysc" sourcefile="halleys.c" cloneof="halleys" romof="halleys">
     // <game name="2020bbh" sourcefile="neogeo.c" cloneof="2020bb" romof="2020bb">
     //
     else if (game.FCloneOf <> '') and (game.FRomOf <> '') and (game.FCloneOf = game.FRomOf) then begin
          // get bios of master, recursive call
          bios := GetBios(GetIndexFromName(game.FRomOf));
     end
     // master with bios: cloneof = '', romof = 'bios'
     // <game name="2020bb" sourcefile="neogeo.c" romof="neogeo">
     //
     else if (game.FCloneOf = '') and (game.FRomOf <> '') then begin
          bios := game.FRomOf;
     end;

     // bios: cloneof = '', romof = '', sourcefile = ''
     // <game runnable="no" name="neogeo">
     //

     Result := bios;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.GetDescription(AIndex: Integer): string;
var
   game: TGame;
begin
     if AIndex = -1 then begin
        Result := '';
        exit;
     end;
     game := FGames.Items[AIndex];
     Result := game.FDescription;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.GetName(AIndex: Integer): string;
var
   game: TGame;
begin
     if AIndex = -1 then begin
        Result := '';
        exit;
     end;
     game := FGames.Items[AIndex];
     Result := game.FName;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.Load(reader: TReader);
var
   i: Integer;
   newgame: TGame;
begin
     try
         with reader do begin
              ReadListBegin;
              while not EndOfList do begin

                    FName := ReadString;
                    FAutor := ReadString;
                    FComment := ReadString;
                    FCreated := ReadDate;
                    FModified := ReadDate;
                    FWriteProtected := ReadBoolean;

                    FGameCount := ReadInteger;

                    FSortField := ReadInteger;

              end;
              ReadListEnd;
         end;

        for i := 0 to FGameCount - 1 do
        begin
             newgame := TGame.Create;
             newgame.Load(reader);
             FGames.Add(newgame);
        end;
     except
           Application.MessageBox('Error reading game list file xxxx!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.Remove(AIndex: Integer);
begin
     TGame(FGames.Items[AIndex]).Destroy;
     FGames.Delete(AIndex);
     FGames.Capacity := FGames.Count;
     FGameCount := FGames.Count;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.Save(writer: TWriter);
var
   i: Integer;
begin
     try
         with writer do begin
              WriteListBegin;

              WriteString(FName);
              WriteString(FAutor);
              WriteString(FComment);
              WriteDate(FCreated);
              WriteDate(FModified);
              WriteBoolean(FWriteProtected);

              WriteInteger(FGames.Count);

              WriteInteger(FSortField);

              WriteListEnd;
         end;

         for i := 0 to FGames.Count - 1 do
         begin
              TGame(FGames.Items[i]).Save(writer);
         end;
     except
           Application.MessageBox('Error writing game list file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.Sort(SortField: Integer);
var
   _sort: Integer;
begin
     if SortField = SORT_GAMELIST then _sort := FSortField
     else _sort := SortField;

     case _sort of
     0: FGames.Sort(@CompareByDescription);
     1: FGames.Sort(@CompareByName);
     2: FGames.Sort(@CompareByGenre);
     3: FGames.Sort(@CompareByPlayed);
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.XmlScannerXmlProlog(Sender: TObject; XmlVersion,
  Encoding: String; Standalone: Boolean);
          // This is called when the scanner has read in the XML prolog
          // XmlVersion: XML version number
          // Encoding:   The encoding declared in the Prolog
          // Standalone: TRUE if 'yes' was specified in the Prolog
begin
     //
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.XmlScannerPI(Sender: TObject; Target, Content: String;
  Attributes: TAttrList);
            // This is called when the scanner has read a Processing Instruction (PI)
begin
     //
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.XmlScannerStartTag(Sender: TObject; TagName: String;
  Attributes: TAttrList);
          // This is called when the scanner has read a Start Tag
          // TagName:    Name of the Start Tag (case sensitive)
          // Attributes: List of Attributes (TAttr Objects)
var
   _mameversion: string;
begin
     // MAME version
     if TagName = _MAME then begin
        _mameversion := Trim(Copy(Attributes.Value('build'),0,5));
        if _mameversion = '' then FMameversion := 0
        else begin
             try
                If Pos('u', _mameversion) > 0 then _mameversion := Copy(_mameversion, 0, Pos('u', _mameversion) - 1);
                FMameVersion := StrToInt(Copy(_mameversion, Pos('.',_mameversion) + 1,Length(_mameversion)));
             except
                FMameversion := 0;
                frmMain.Log(mtError, 'Could not get MAME Version from XML');
             end;
             frmMain.Log(mtInfo, 'MAME Version from XML: ' + IntToStr(FMameVersion));
        end;
     end;

     // new game element
     if TagName = _GAME then begin

        TheGame := nil;
        TheGame := TGame.Create;
        GameCompleted := false;

        TheGame.FName := Attributes.Value('name');
        TheGame.FCloneOf := Attributes.Value('cloneof');
        TheGame.FRomOf := Attributes.Value('romof');
        TheGame.FSourcefile := Attributes.Value('sourcefile');

        //(mtDebug, 'Seaching for rom: ' + TheGame.FName);
     end;

     // description
     if (TagName = _DESCRIPTION) and (TheGame <> nil) then begin
        CurrentElement := ELEMENT_DESCRIPTION;
     end;

     // year
     if (TagName = _YEAR) and (TheGame <> nil) then begin
        CurrentElement := ELEMENT_YEAR;
     end;

     // manufacturer
     if (TagName = _MANUFACTURER) and (TheGame <> nil) then begin
        CurrentElement := ELEMENT_MANUFACTURER;
     end;

     // input
     if (FMameVersion > 106) and (TagName = _INPUT) and (TheGame <> nil) then begin
        try
           TheGame.FInputButtons := StrToInt(Attributes.Value('buttons'));
        except
              TheGame.FInputButtons := 0;
        end;
        try
           TheGame.FInputCoins := StrToInt(Attributes.Value('coins'));
        except
              TheGame.FInputCoins := 0;
        end;

        TheGame.FInputPlayers := Attributes.Value('players');
     end;

     // control
     if (FMameVersion <= 106) and (TagName = _CONTROL) and (TheGame <> nil) then begin
        CurrentElement := ELEMENT_CONTROL;
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.XmlScannerEndTag(Sender: TObject; TagName: String);
          // This is called when the scanner has read an End tag
          // TagName: Name of the End Tag (case sensitive)
var
   dir: string;
   catindex: Integer;
   i: Integer;
   NoGames: Boolean;
begin

         
    // frmMain.Log(mtDebug, 'XmlScannerEndTag: ' );

      NoGames := True;
     // game element
     // add to list
     if (TagName = _GAME)  and (TheGame <> nil) then begin
    //  frmMain.Log(mtDebug, 'XmlScannerEndTag: GAME');

        if GameCompleted then begin

            AddTheGame := true;

            // only games with roms, search rom file in all rom folders
            if frmMain.FGameListOptionHaving then begin

               if frmMain.FPathRoms1 <> '' then begin
                  dir := IncludeTrailingBackslash(frmMain.FPathRoms1);
                  CurrentFolder := dir;
                  //if frmMain.FSearchInSubDirs then begin

                     AddTheGame := False;
               //      If NoGames = TRUE then frmMain.Log(mtDeBug, 'rom - '+ TheGame.FName + ' Not Added: Reason: No Rom Found in path1 '+ frmMain.FPathRoms1 +' (Game Collection Option)');
                     frmMain.FindRom.OnFound := FindFileFound;
                     frmMain.FindRom.OnNewFolder := FindFileNewFolder;
                     frmMain.FindRom.Filename := TheGame.FName + '.zip';
                     frmMain.FindRom.Attributes := [ffArchive];
                     frmMain.FindRom.Subfolders := frmMain.FSearchInSubDirs;
                     frmMain.FindRom.ExactAttribute := False;
                     frmMain.FindRom.Location := dir;
                     frmMain.FindRom.Execute;

                  //end
                  //else AddTheGame := FileExists(dir + TheGame.FName + '.zip') or FileExists(dir + TheGame.FName + '.ZIP');
               end;

               if not AddTheGame and (frmMain.FPathRoms2 <> '') then begin
                  dir := IncludeTrailingBackslash(frmMain.FPathRoms2);
                  CurrentFolder := dir;
                  //if frmMain.FSearchInSubDirs then begin

                     AddTheGame := False;
                //     If NoGames = TRUE then  frmMain.Log(mtDeBug, 'rom - '+ TheGame.FName + ' Not Added: Reason: No Rom Found in path2 '+ frmMain.FPathRoms2 +' (Game Collection Option)');
                     frmMain.FindRom.OnFound := FindFileFound;
                     frmMain.FindRom.OnNewFolder := FindFileNewFolder;
                     frmMain.FindRom.Filename := TheGame.FName + '.zip';
                     frmMain.FindRom.Attributes := [ffArchive];
                     frmMain.FindRom.Subfolders := frmMain.FSearchInSubDirs;
                     frmMain.FindRom.ExactAttribute := False;
                     frmMain.FindRom.Location := dir;
                     frmMain.FindRom.Execute;

                  //end
                  //else AddTheGame := FileExists(dir + TheGame.FName + '.zip') or FileExists(dir + TheGame.FName + '.ZIP');
               end;

               if not AddTheGame and (frmMain.FPathRoms3 <> '') then begin
                  dir := IncludeTrailingBackslash(frmMain.FPathRoms3);
                  CurrentFolder := dir;
                  //if frmMain.FSearchInSubDirs then begin

                     AddTheGame := False;
            //         If NoGames = TRUE then frmMain.Log(mtDeBug, 'rom - '+ TheGame.FName + ' Not Added: Reason: No Rom Found in path3 '+ frmMain.FPathRoms3 +' (Game Collection Option)');
                     frmMain.FindRom.OnFound := FindFileFound;
                     frmMain.FindRom.OnNewFolder := FindFileNewFolder;
                     frmMain.FindRom.Filename := TheGame.FName + '.zip';
                     frmMain.FindRom.Attributes := [ffArchive];
                     frmMain.FindRom.Subfolders := frmMain.FSearchInSubDirs;
                     frmMain.FindRom.ExactAttribute := False;
                     frmMain.FindRom.Location := dir;
                     frmMain.FindRom.Execute;

                  //end
                  //else AddTheGame := FileExists(dir + TheGame.FName + '.zip') or FileExists(dir + TheGame.FName + '.ZIP');
               end;
            end;

            // only working games
            if frmMain.FGameListOptionWorking and AddTheGame then begin
               if (TheGame.FDriverEmulation <> 'good') then
               begin
               AddTheGame := false;
               If NoGames = TRUE then frmMain.Log(mtDeBug, 'rom - '+ TheGame.FName + ' Not Added: Reason: Not Working game, Emulation Bad (Game Collection Option)');
               end;
                  if frmMain.FGameListOptionPreliminary then begin
                     if (TheGame.FDriverEmulation = 'preliminary') then AddTheGame := true;
                  end;
            end;

            // only master games
            if frmMain.FGameListOptionMaster and AddTheGame then begin
               if TheGame.FCloneOf <> '' then
               begin
               AddTheGame := false;
               If NoGames = TRUE then frmMain.Log(mtDeBug, 'rom - '+ TheGame.FName + ' Not Added: Reason: Not a master (Game Collection Option)');
               end;
            end;

            // excludes
            if (frmMain.FGameListOptionExcludes.Count > 0) and AddTheGame then begin
               i := 0;
               while AddTheGame and (i < frmMain.FGameListOptionExcludes.Count) do begin
                     if Pos(Uppercase(frmMain.FGameListOptionExcludes.Strings[i]), Uppercase(TheGame.FDescription)) > 0 then
               begin
               AddTheGame := false;
               If NoGames = TRUE then frmMain.Log(mtDeBug, 'rom - '+ TheGame.FName + ' Not Added: Reason: Game in exclude list (Game Collection Option)');
               end;
                     Inc(i);
               end;
            end;

            if AddTheGame then begin

                // path of rom
                //TheGame.FRomPath := CurrentFolder;

                // add genre from catver file
                if cat_file.Count > 0 then begin
                   catindex := cat_file.IndexOfName(TheGame.FName);
                   if catindex >= 0 then begin
                      TheGame.FGenre := Trim(Copy(cat_file.Strings[catindex], Pos('=', cat_file.Strings[catindex]) + 1, Length(cat_file.Strings[catindex])));
                   end
                   else begin
                        TheGame.FGenre := '';
                   end;
                end
                else begin
                     TheGame.FGenre := '';
                end;

                // get controls
                GetGameControls(TheGame.FName, TheGame.FCloneOf);

                if nplayers_file <> nil then
                begin
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: nplayers.ini info: FInputPlayers= '+TheGame.FName+' '+TheGame.FCloneOf);
                TheGame.FInputPlayers := GetNPlayersEntry(TheGame.FName, TheGame.FCloneOf);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: nplayers.ini info: FInputPlayers= '+TheGame.FName+' '+TheGame.FCloneOf);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: nplayers.ini info: Section 1');
                end
                else
                begin
                  if controls_file <> nil then
                  begin
                  frmMain.Log(mtDeBug, 'XmlScannerEndTag: nplayers.ini info: Section 2');
                    TheGame.FInputPlayers := TheGame.FInputPlayers + 'P';
                    if (TheGame.FInputPlayers <> '1P') then
                    begin
                    frmMain.Log(mtDeBug, 'XmlScannerEndTag: nplayers.ini info: Section 3');
                    if FGameControls.Alternating = '1' then TheGame.FInputPlayers := TheGame.FInputPlayers + ' alt'
                    else TheGame.FInputPlayers := TheGame.FInputPlayers + ' sim';
                    end;
                   end
                   else
                   begin
                   frmMain.Log(mtDeBug, 'XmlScannerEndTag: nplayers.ini info: Section 4');
                   TheGame.FInputPlayers := TheGame.FInputPlayers + 'P';
                   end;
                   frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FInputPlayers= '+ theGame.FName+' '+TheGame.FInputPlayers);
                end;

                TheGame.FControls := FGameControls.Controls;
                TheGame.FJoyUp := FGameControls.JoyUp;
                TheGame.FJoyDown := FGameControls.JoyDown;
                TheGame.FJoyLeft := FGameControls.JoyLeft;
                TheGame.FJoyRight := FGameControls.JoyRight;
                TheGame.FButton1 := FGameControls.Button1;
                TheGame.FButton2 := FGameControls.Button2;
                TheGame.FButton3 := FGameControls.Button3;
                TheGame.FButton4 := FGameControls.Button4;
                TheGame.FButton5 := FGameControls.Button5;
                TheGame.FButton6 := FGameControls.Button6;
                TheGame.FButton7 := FGameControls.Button7;
                TheGame.FButton8 := FGameControls.Button8;
                TheGame.FDetails := FGameControls.Details;

                // finally add the game to the list
                Add(TheGame);
                frmmain.FGamesAdded := frmmain.FGamesAdded + 1;
                frmMain.Log(mtDeBug, 'rom '+ Inttostr(frmmain.FGamesAdded) +' '+ TheGame.FName+' added to All Games list');
                // Debug Log Game Attributes
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FName= '+  TheGame.FName);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FRomOf= '+  TheGame.FRomOf);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FCloneOf= '+  TheGame.FCloneOf);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FSourcefile= '+  TheGame.FSourcefile);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FDescription= '+  TheGame.FDescription);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FManufacturer= '+  TheGame.FManufacturer);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FGenre= '+  TheGame.FGenre);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FInputControl= '+  TheGame.FInputControl);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FVideoScreen= '+  TheGame.FVideoScreen);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FVideoOrientation= '+  TheGame.FVideoOrientation);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FDriverStatus= '+  TheGame.FDriverStatus);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FDriverColor= '+  TheGame.FDriverColor);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FDriverSound= '+  TheGame.FDriverSound);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FDriverEmulation= '+  TheGame.FDriverEmulation);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FDriverGraphic= '+  TheGame.FDriverGraphic);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FRomPath= '+  TheGame.FRomPath);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: mame.xml info FExtension= '+  TheGame.FExtension);
                // Debug Log controls.ini info
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FControls= '+TheGame.FControls);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FJoyUp= '+TheGame.FJoyUp);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FJoyDown= '+TheGame.FJoyDown);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FJoyLeft= '+TheGame.FJoyLeft);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FJoyRight= '+TheGame.FJoyRight);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FButton1= '+TheGame.FButton1);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FButton2= '+TheGame.FButton2);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FButton3= '+TheGame.FButton3);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FButton4= '+TheGame.FButton4);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FButton5= '+TheGame.FButton5);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FButton6= '+TheGame.FButton6);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FButton7= '+TheGame.FButton7);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FButton8= '+TheGame.FButton8);
                frmMain.Log(mtDeBug, 'XmlScannerEndTag: controls.ini info: FDetails= '+TheGame.FDetails);

                NoGames := False;
                TheGame := nil;
            end;
        end;

     end;

end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.XmlScannerEmptyTag(Sender: TObject; TagName: String;
  Attributes: TAttrList);
          // This is called when the scanner has read an XML Empty-Element Tag (e.g. <BR/>
          // TagName: Name of the Tag (case sensitive)
          // Attributes: List of Attributes (TAttr Objects)
var
   video_tag: string;
   _orientation: string;
begin
     // video
     if (FMameVersion > 106) then video_tag := _VIDEO107
     else video_tag := _VIDEO106 ;

     if (TagName = video_tag) and (TheGame <> nil) then begin

        if (FMameVersion > 106) then begin
           TheGame.FVideoScreen := Attributes.Value('type');
           _orientation := Attributes.Value('rotate');
           TheGame.FVideoOrientation := '';
           if (_orientation = '0') or (_orientation = '180') then TheGame.FVideoOrientation := 'horizontal';
           if (_orientation = '90') or (_orientation = '270') then TheGame.FVideoOrientation := 'vertical';
        end
        else begin
           TheGame.FVideoScreen := Attributes.Value('screen');
           TheGame.FVideoOrientation := Attributes.Value('orientation');
        end;

        try
           TheGame.FVideoWidth := StrToInt(Attributes.Value('width'));
        except
              TheGame.FVideoWidth := 0;
        end;
        try
           TheGame.FVideoHeight := StrToInt(Attributes.Value('height'));
        except
              TheGame.FVideoHeight := 0;
        end;
     end;

     // input
     if (FMameVersion <= 106) and (TagName = _INPUT) and (TheGame <> nil) then begin
        try
           TheGame.FInputButtons := StrToInt(Attributes.Value('buttons'));
        except
              TheGame.FInputButtons := 0;
        end;
        try
           TheGame.FInputCoins := StrToInt(Attributes.Value('coins'));
        except
              TheGame.FInputCoins := 0;
        end;

        TheGame.FInputPlayers := Attributes.Value('players');
        TheGame.FInputControl := Attributes.Value('control');
     end;

     // control
     if (FMameVersion > 106) and (TagName = _CONTROL) and (TheGame <> nil) then begin
        TheGame.FInputControl := Attributes.Value('type');
     end;

     // driver
     if (TagName = _DRIVER) and (TheGame <> nil) then begin
        TheGame.FDriverStatus := Attributes.Value('status');
        TheGame.FDriverColor := Attributes.Value('color');
        TheGame.FDriverSound := Attributes.Value('sound');
        TheGame.FDriverEmulation := Attributes.Value('emulation');
        TheGame.FDriverGraphic := Attributes.Value('graphic');

        GameCompleted := true;
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.XmlScannerComment(Sender: TObject; Comment: String);
          // This is called when the scanner has read a Comment
begin
     //
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.XmlScannerContent(Sender: TObject; Content: String);
          // This is called when the scanner has read element text content
          // The "OnCData" event of XmlScanner also points to this routine
          // Content: The text content
begin
     if TheGame <> nil then begin
         case CurrentElement of
         ELEMENT_DESCRIPTION:
         begin
              TheGame.FDescription := Content;
              CurrentElement := ELEMENT_NONE;
         end;
         ELEMENT_YEAR:
         begin
              try
                 TheGame.FYear := StrToInt(Content);
              except
                    TheGame.FYear := 0;
              end;
              CurrentElement := ELEMENT_NONE;
         end;
         ELEMENT_MANUFACTURER:
         begin
              TheGame.FManufacturer := Content;
              CurrentElement := ELEMENT_NONE;
         end;
         end;

     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.XmlScannerDtdRead(Sender: TObject;
  RootElementName: String);
begin
     if RootElementName <> 'mame' then begin
        // stop parser
        XmlScanner.StopParser := true;
        Application.MessageBox('This is not a valid mame xml file!', PChar(APP_NAME), MB_OK + MB_ICONERROR);
     end;
end;


{*******************************************************************************
*
*******************************************************************************}
function TGameList.GetAsStrings: TStringList;
var
   i: Integer;
   gamelist: TStringList;
begin
     gamelist := TStringList.Create;
     for i := 0 to FGameCount - 1 do
     begin
          if (TGame(FGames.Items[i]).FDriverStatus = 'file') then begin

             gamelist.Add(TGame(FGames.Items[i]).FName);
          end;
     end;
     Result := gamelist;
end;

{*******************************************************************************
*
*******************************************************************************}
function TGameList.GetNPlayersEntry(ARomName, AMasterName: string): string;
var
   tmp, section: string;
   gamefound: Boolean;
begin
     if nplayers_file <> nil then begin
           section := 'NPlayers';
           tmp := nplayers_file.ReadString(section, ARomName, '');

       if tmp = '' then
        begin
        frmMain.Log(mtDeBug, 'GetNPlayersEntry: nplayers.ini No Entry For '+AromName+' '+tmp);
        try
        tmp := nplayers_file.ReadString(section, AMasterName, '');
        frmMain.Log(mtDeBug, 'GetNPlayersEntry: nplayers.ini Found Master '+AromName+' '+tmp);
        except
        frmMain.Log(mtError, 'GetNPlayersEntry: nplayers.ini No Master Entry found For '+AromName+' '+tmp);
        end;
        end;

       Result := tmp;
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.GetGameControls(ARomName, AMasterName: string);
var
   tmp, section: string;
   gamefound: Boolean;
begin
     if controls_file <> nil then begin

           section := ARomName;
           gamefound := controls_file.SectionExists(section);
           if not gamefound then begin
                if AMasterName <> '' then begin
                   section := AMasterName;
                   gamefound := controls_file.SectionExists(section);
                end;
           end;

           if gamefound then begin
              // fill record
              tmp := controls_file.ReadString(section, 'P1Controls', '');

              FGameControls.Controls := Copy(tmp, 0, Pos('+', tmp) - 1);

              FGameControls.NumPlayers := controls_file.ReadString(section, 'numPlayers', '0');
              FGameControls.Alternating := controls_file.ReadString(section, 'alternating', '0');

              FGameControls.JoyUp := controls_file.ReadString(section, 'P1_JOYSTICK_UP', '');
              FGameControls.JoyDown := controls_file.ReadString(section, 'P1_JOYSTICK_DOWN', '');
              FGameControls.JoyLeft := controls_file.ReadString(section, 'P1_JOYSTICK_LEFT', '');
              FGameControls.JoyRight := controls_file.ReadString(section, 'P1_JOYSTICK_RIGHT', '');

              FGameControls.Button1 := controls_file.ReadString(section, 'P1_BUTTON1', 'not used');
              FGameControls.Button2 := controls_file.ReadString(section, 'P1_BUTTON2', 'not used');
              FGameControls.Button3 := controls_file.ReadString(section, 'P1_BUTTON3', 'not used');
              FGameControls.Button4 := controls_file.ReadString(section, 'P1_BUTTON4', 'not used');
              FGameControls.Button5 := controls_file.ReadString(section, 'P1_BUTTON5', 'not used');
              FGameControls.Button6 := controls_file.ReadString(section, 'P1_BUTTON6', 'not used');
              FGameControls.Button7 := controls_file.ReadString(section, 'P1_BUTTON7', 'not used');
              FGameControls.Button8 := controls_file.ReadString(section, 'P1_BUTTON8', 'not used');

              FGameControls.Details := controls_file.ReadString(section, 'miscDetails', '');
           end
           else begin
                // clear record
              FGameControls.Controls := '';

              FGameControls.NumPlayers := '';
              FGameControls.Alternating := '';

              FGameControls.JoyUp := '';
              FGameControls.JoyDown := '';
              FGameControls.JoyLeft := '';
              FGameControls.JoyRight := '';

              FGameControls.Button1 := '';
              FGameControls.Button2 := '';
              FGameControls.Button3 := '';
              FGameControls.Button4 := '';
              FGameControls.Button5 := '';
              FGameControls.Button6 := '';
              FGameControls.Button7 := '';
              FGameControls.Button8 := '';

              FGameControls.Details := '';
           end;



     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.FindFileFound(Sender: TObject; Folder: String;
  var FileInfo: TSearchRec);
var
   _pos: Integer;
begin
     case SearchMameRoms of
     True:
     begin
             // add path and extension to mame rom
             TheGame.FRomPath := CurrentFolder;
             TheGame.FExtension := 'zip';

             AddTheGame := True;

             frmMain.FindRom.Abort;
     end;
     False:
     begin
             // remove extension
             _pos := Pos('.' + UpperCase(CurrentExt), UpperCase(FileInfo.Name));
             TheGame := TGame.Create;
             TheGame.FName := Copy(FileInfo.Name, 0, _pos - 1);

             if readtxt or readlnk then begin
                 if readtxt then begin
                   try
                      txtfile := TStringList.Create;
                      txtfile.LoadFromFile(IncludeTrailingBackslash(CurrentFolder) + FileInfo.Name);
                      TheGame.FDescription := trim(txtfile.Strings[0]);
                      txtFile.Free;
                   except
                   end;
                 end;
                 if readlnk then begin
                   try
                      TheGame.FDescription := Copy(FileInfo.Name, 0, _pos - 1);
                      TheGame.FName := GetTarget(IncludeTrailingBackslash(CurrentFolder) + FileInfo.Name);
                   except
                   end;
                 end;
             end
             else begin
                  TheGame.FDescription := TheGame.FName;
             end;

             // add path
             TheGame.FRomPath := CurrentFolder;

             // add extension
             TheGame.FExtension := CurrentExt;

             // add the game
             Add(TheGame);

             frmMain.Log(mtInfo, 'Found game: ' + TheGame.FName + ' in dir: ' + TheGame.FRomPath);
     end;
     end;
end;

{*******************************************************************************
*
*******************************************************************************}
procedure TGameList.FindFileNewFolder(Sender: TObject; Folder: String;
  var IgnoreFolder: Boolean);
begin
     CurrentFolder := ExcludeTrailingBackslash(Folder);
     //frmMain.Log(mtInfo, 'Seaching in dir: ' + CurrentFolder);
end;


end.
